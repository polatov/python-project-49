#!/usr/bin/env python3

# from brain_games.cli import welcome_user


def print_welcome_message():
    print("Welcome to the Brain Games!")


def main() -> object:
    print_welcome_message()
    # user_name = welcome_user()


if __name__ == '__main__':
    main()
